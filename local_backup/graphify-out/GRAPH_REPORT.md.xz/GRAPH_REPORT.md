# Graph Report - nba_match_prediction  (2026-10-24)

## Corpus Check
- 90 files · ~110,589 words
- Verdict: corpus is large enough that graph structure adds value.
- Unclassified: 30 file(s) not represented in the graph (top: .csv 16, .pkl 10, (none) 2)

## Summary
- 1523 nodes · 3730 edges · 88 communities (80 shown, 8 thin omitted)
- Extraction: 94% EXTRACTED · 6% INFERRED · 0% AMBIGUOUS · INFERRED: 228 edges (avg confidence: 0.87)
- Token cost: 833,131 input · 0 output

## Community Hubs (Navigation)
- Legacy nba_api retrievers
- Defensive tracking features
- Power rankings engine
- Dashboard Flask routes
- Matchup impact features
- Local cache backup
- Dashboard page script
- Training protocol harness
- Legacy 2023-24 predictor
- Season retrieval (V2 endpoints)
- Original impact engine
- Production retraining
- Simulator runner and sandbox
- Score simulator
- Play-by-play retrieval
- Pregame roster features
- Consistency lab experiments
- Season simulation replications
- Market check and probes
- Walk-forward evaluation
- Simulator forecast inputs
- Box score retrieval (V2)
- Value engine pipeline
- Team strength ratings
- MariaDB source (legacy)
- Seed ensemble and blend
- Dashboard rendering helpers
- Impact visualisation scripts
- Assist tuning and CLI scripts
- Probability calibration
- Simulated season reader
- Dashboard state loading
- Impact common helpers
- Simulator team priors
- 2025-26 legacy impact scoring
- CSV master loader
- Player season projection
- Player games source
- Availability features
- Value score and OVR concepts
- Ensemble and staleness probes
- Possession simulator concepts
- 2025-26 feature engineering
- Legacy impact score features
- Phone DB cache loader
- Leak verification scripts
- Derived DB impact tables
- Status and leak findings
- Impact v5 lab
- Schema and timing probes
- Simulated possession mechanics
- Data stores and lost loader
- Impact feature rebuild
- Season impact analysis v1
- 2025-26 model analysis
- Dependencies and model comparison
- 2025-26 predictor features
- Information ceiling analysis
- Phone DB paged fetch
- Dashboard metadata API
- Season retrieval (V3 endpoints)
- Assist passer matching
- DB dataset builder
- Clutch features
- Per-game value computation
- Defensive and tracking backfill
- Impact v5 rollout
- Forward-looking roster impact
- Two-arm retraining
- Simulator team sheets
- Matchup retrieval
- Season impact analysis
- README impact score history
- Value pricing rules
- Phone DB connection link
- Play-by-play DB tables
- Simulator player profiles
- Legacy impact score critique
- Simulated rankings bridge
- Dashboard player rankings view
- Matchup retraining ablation
- Season game-id fetcher
- DB connectivity probe
- Phone DB pull checkpoints
- Pregame player state
- Simulated game scoring
- Phone DB table spec

## God Nodes (most connected - your core abstractions)
1. `prepare_season()` - 23 edges
2. `simulate_season()` - 23 edges
3. `is_clutch_time()` - 22 edges
4. `main()` - 22 edges
5. `RankingEngine` - 21 edges
6. `calculate_rebound_impact()` - 19 edges
7. `calculate_block_impact()` - 18 edges
8. `calculate_scoring_impact()` - 18 edges
9. `renderDetail()` - 18 edges
10. `calculate_steal_impact()` - 17 edges

## Surprising Connections (you probably didn't know these)
- `monotone_signs()` --implements--> `Hyperparameter search and monotone constraints on signed features`  [INFERRED]
  prediction_engines/retrain_production.py → output/IMPROVEMENT_REPORT.md
- `renderDetail()` --shares_data_with--> `_calibrated()`  [INFERRED]
  templates/index.html → app.py
- `renderDetail()` --shares_data_with--> `_simulate_game()`  [INFERRED]
  templates/index.html → app.py
- `renderDetail()` --shares_data_with--> `_ratings_for_game()`  [INFERRED]
  templates/index.html → app.py
- `renderDetail()` --shares_data_with--> `_matchup_data()`  [INFERRED]
  templates/index.html → app.py

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Model-side readers switched to game_impact_cache_v5.pkl in the v5 rollout** — prediction_engines_build_dataset_db, prediction_engines_db_source, prediction_engines_pregame_roster, prediction_engines_player_source, prediction_engines_player_simulation, prediction_engines_db_build_derived, prediction_engines_predict_2025_2026, durum_game_impact_cache_v5 [EXTRACTED 1.00]
- **Pricing 5.1 rebuild chain: value_engine -> impact_v5 -> rebuild_impact_features -> retrain_production** — prediction_engines_value_engine, durum_value_cache_unweighted, prediction_engines_impact_v5, durum_game_impact_cache_v5, prediction_engines_rebuild_impact_features, prediction_engines_retrain_production [EXTRACTED 1.00]
- **Base tables the CSV-to-MariaDB loader must build** — db_kurtarma_games_table, db_kurtarma_game_summary_table, db_kurtarma_game_dates_table, db_kurtarma_box_team_traditional_table, db_kurtarma_box_team_advanced_table, db_kurtarma_box_player_traditional_table, db_kurtarma_training_games_table, db_kurtarma_play_by_play_table [EXTRACTED 1.00]
- **Top 5 prioritized improvements** — output_improvement_report_ratings_baseline, output_improvement_report_probability_calibration, output_improvement_report_walk_forward_cv, output_improvement_report_unused_extracted_features, output_improvement_report_rest_b2b_features, output_improvement_report_bundled_ablation [EXTRACTED 1.00]
- **In-game roster leak: shipped as leak-free, found, rebuilt from pre-game active lists** — output_improvement_report_roster_impact_module, experiments_2026_10_readme_roster_count_leak, experiments_2026_10_readme_pregame_roster_clean, prediction_engines_pregame_roster, odds_data_readme_stale_model_vs_market, templates_index_honesty_panel [INFERRED 0.85]
- **Impact pricing 5.1: from hand-tuned weights to point-priced value** — output_improvement_report_magic_weights, prediction_engines_value_engine, experiments_2026_10_readme_impact_pricing_5_1, experiments_2026_10_readme_assist_credit_rule, templates_index_value_score [INFERRED 0.85]

## Communities (88 total, 8 thin omitted)

### Community 0 - "Legacy nba_api retrievers"
Cohesion: 0.07
Nodes (20): retrieve_play_by_play(), save_to_csv(), check_if_data_exists(), get_regular_season_game_ids(), get_season_formatted_filename(), process_all_games(), retrieve_play_by_play(), save_game_ids_to_csv() (+12 more)

### Community 1 - "Defensive tracking features"
Cohesion: 0.06
Nodes (26): defensive_box_score_unavailable_games.txt (8 games without a defensive box score), Game 0021900369 (2019-20), Game 0021900380 (2019-20), Game 0021900669 (2019-20), Game 0021900792 (2019-20), Game 0022100132 (2021-22), Game 0022300383 (2023-24), Game 0022301192 (2023-24) (+18 more)

### Community 2 - "Power rankings engine"
Cohesion: 0.09
Nodes (13): Team OVR = 85 + 1.1 x power (60-99), attach_value(), _label_range(), _load_sibling(), main(), player_games_with_minutes(), player_ovr_from_percentile(), RankingEngine (+5 more)

### Community 3 - "Dashboard Flask routes"
Cohesion: 0.11
Nodes (25): api_games(), api_predict(), api_ranking_periods(), api_ranking_players(), api_rankings(), api_sim_game(), api_sim_games(), api_sim_leaders() (+17 more)

### Community 4 - "Matchup impact features"
Cohesion: 0.08
Nodes (16): add_matchup_features(), _add_trailing(), build_defender_game_table(), build_offense_game_table(), _detect_seasons(), _full_name(), get_current_matchup_impact(), _get_default_instance() (+8 more)

### Community 5 - "Local cache backup"
Cohesion: 0.11
Nodes (19): Phone-hosted MariaDB 'phonedb' (lost 2026-09-03), Compressed backup of git-ignored caches (local_backup/), matchup_cache_v1.pkl, phonedb_cache/ (12 tables, pulled 12 Sept 2026), env_keys_found_in(), env_secrets(), local_files(), main() (+11 more)

### Community 6 - "Dashboard page script"
Cohesion: 0.11
Nodes (30): index.html (NBA Tahmin Paneli dashboard), currentTeam(), ensurePeriods(), fillPeriods(), getJSON(), URL hash deep links (#game, #rank, #sim, #simgame), loadGames(), loadRank() (+22 more)

### Community 7 - "Training protocol harness"
Cohesion: 0.11
Nodes (12): calibrated(), fit_logistic(), fit_weighted_classifier(), margin_to_probability(), paired_delta(), run_cell(), _score(), score_margin_probability() (+4 more)

### Community 8 - "Legacy 2023-24 predictor"
Cohesion: 0.09
Nodes (4): FeatureEngineer, GameDataLoader, ImpactScoreCalculator, NBAPredictor

### Community 9 - "Season retrieval (V2 endpoints)"
Cohesion: 0.13
Nodes (13): format_season(), read_game_ids(), check_if_pbp_data_exists(), check_if_tracking_data_exists(), format_game_id(), get_retry_delay(), process_all_seasons(), process_season_data() (+5 more)

### Community 10 - "Original impact engine"
Cohesion: 0.17
Nodes (13): calculate_enhanced_impact_score(), get_score_margin(), is_clutch_time(), calculate_foul_impact(), calculate_rebound_impact(), calculate_scoring_impact(), calculate_steal_impact(), calculate_turnover_impact() (+5 more)

### Community 11 - "Production retraining"
Cohesion: 0.13
Nodes (16): Consistency lab experiments (two paired rounds), output/metrics_2025_26.json, Next step: pre-game injury report feed, roster_missing_impact, chrono_split(), fit_members(), honest_numbers(), impact_pricing_version() (+8 more)

### Community 12 - "Simulator runner and sandbox"
Cohesion: 0.13
Nodes (11): compare_with_real(), fingerprint_project(), league_averages(), main(), player_table(), print_comparison(), real_reference(), Sandbox (+3 more)

### Community 13 - "Score simulator"
Cohesion: 0.11
Nodes (13): Poisson / Tweedie score targets with Skellam-derived win probability, chrono_split(), coverage(), _draw_counts(), estimate_correlation(), estimate_dispersion(), evaluate(), fit_rate_model() (+5 more)

### Community 14 - "Play-by-play retrieval"
Cohesion: 0.14
Nodes (12): calculate_progress_percentage(), check_if_pbp_data_exists(), check_if_tracking_data_exists(), create_season_dir(), format_game_id(), get_season_formatted(), process_all_seasons(), process_season_games() (+4 more)

### Community 15 - "Pregame roster features"
Cohesion: 0.13
Nodes (12): Pre-game active-list roster features carry no game information (corr -0.015), build_from_dataset(), build_pregame_features(), load_impacts(), load_listings(), load_matchup_totals(), main(), parse_minutes() (+4 more)

### Community 16 - "Consistency lab experiments"
Cohesion: 0.14
Nodes (15): arm_definitions(), clf_scores(), collect(), fit_arm(), load_frame(), main(), _metric(), monotone_signs() (+7 more)

### Community 17 - "Season simulation replications"
Cohesion: 0.10
Nodes (10): Simulator backtest mode, Pre-season win forecast is no better than 'same as last season', 10-90% win range coverage (team deviation 0.10 covers 77%; 0.11 chosen), Season simulator experiments, Simulator knobs: tempo, home advantage and score effect (six seeds), Availability, _impact_entry(), replicate() (+2 more)

### Community 18 - "Market check and probes"
Cohesion: 0.14
Nodes (18): get(), paired(), Leakage investigation scripts, Walk-forward: month effect far larger than seed effect, In-game roster leak: players-used count correlates 0.64 with |margin|, Single-feature AUC ceiling (best 0.69, none above 0.75), README.md (odds_data: market odds for the 2025-26 held-out period), nba_2025_26_heldout_odds.csv (theScore and DraftKings odds, 308 held-out games) (+10 more)

### Community 19 - "Walk-forward evaluation"
Cohesion: 0.13
Nodes (14): Single chronological split: 2152 train games, last 308 of 2025-26 as test, Walk-forward CV with leak-free early stopping, add_team_game_index(), clf_scores(), collect(), fit_classifier(), fit_regressor(), load_any_dataset() (+6 more)

### Community 20 - "Simulator forecast inputs"
Cohesion: 0.11
Nodes (13): 2026-27 forecast run (sim_sandbox/forecast_2026_2027), Simulator forecast mode, Simulator mechanics mode, fetch_rosters(), fetch_schedule(), load_box(), nba_season_label(), opening_rosters() (+5 more)

### Community 21 - "Box score retrieval (V2)"
Cohesion: 0.18
Nodes (10): check_if_box_score_data_exists(), format_game_id(), get_retry_delay(), process_all_seasons(), process_season_data(), retrieve_advanced_box_score(), retrieve_defensive_box_score(), retrieve_traditional_box_score() (+2 more)

### Community 22 - "Value engine pipeline"
Cohesion: 0.16
Nodes (13): box_minutes(), evaluate(), GameContext, load_cache(), load_contexts(), main(), pbp_path(), player_frame() (+5 more)

### Community 23 - "Team strength ratings"
Cohesion: 0.14
Nodes (10): Hyperparameter search and monotone constraints on signed features, Team-strength ratings baseline (Elo / Glicko / TrueSkill), add_rating_features(), _elo_pass(), _impact_vs_expected(), _massey_pass(), _mov_multiplier(), _solve_massey() (+2 more)

### Community 24 - "MariaDB source (legacy)"
Cohesion: 0.12
Nodes (9): attach_impact(), _attach_side(), available_seasons(), connect(), games_missing_impact(), load_pbp(), _phonedb(), read_resilient() (+1 more)

### Community 25 - "Seed ensemble and blend"
Cohesion: 0.13
Nodes (5): BlendedForecaster, load_blend(), load_model(), SeedEnsemble, Three views: classifier, margin and logistic

### Community 26 - "Dashboard rendering helpers"
Cohesion: 0.22
Nodes (17): _badge(), _game_summary(), boxTable(), buildTeamStrip(), color(), gameCard(), held-out / egitimde (in-training) game badge, loadSimLeaders() (+9 more)

### Community 27 - "Impact visualisation scripts"
Cohesion: 0.18
Nodes (8): create_shot_chart(), draw_court(), plot_cumulative_impact(), plot_impact_scores(), visualize_player_breakdown(), calculate_block_impact(), plot_impact_scores(), plot_matchup_matrix()

### Community 28 - "Assist tuning and CLI scripts"
Cohesion: 0.14
Nodes (9): main(), season_dir_name(), tidy(), frame(), frame(), Pricing 5.1 validation (0.421->0.428, 0.482->0.494, 0.388->0.420; better in 5 of 6 untuned seasons), output/value_cache_v1.pkl (value engine cache used as the old baseline), corr() (+1 more)

### Community 29 - "Probability calibration"
Cohesion: 0.18
Nodes (12): apply_calibrator(), chrono_split(), evaluate(), fit_base(), fit_calibrators(), load_dataset(), _logit(), main() (+4 more)

### Community 31 - "Dashboard state loading"
Cohesion: 0.12
Nodes (11): _attach_minutes(), _build_player_games(), _forecast_all(), _load_optional(), _load_sibling(), _load_state(), _team_ids(), _trained_features() (+3 more)

### Community 32 - "Impact common helpers"
Cohesion: 0.18
Nodes (7): load_and_preprocess_data(), calculate_expected_points(), calculate_team_possessions(), categorize_shot_distance(), is_last_2_minutes(), load_and_preprocess_pbp_file(), load_and_preprocess_data()

### Community 33 - "Simulator team priors"
Cohesion: 0.13
Nodes (8): Carry-over of team effects into the next season (none 0.36 / 9.7; half or full ~0.51), build_league(), build_team_priors(), carried_priors(), League, team_game_table(), TeamPrior, _with_derived()

### Community 34 - "2025-26 legacy impact scoring"
Cohesion: 0.24
Nodes (13): Hardcoded Denver/GSW team IDs in legacy impact code, _block_impact(), clock_to_seconds(), expected_points(), _foul_impact(), is_clutch(), is_last_2min(), margin() (+5 more)

### Community 35 - "CSV master loader"
Cohesion: 0.17
Nodes (8): _attach_scores(), _attach_side(), available_seasons(), load_master_frame(), load_schedule(), load_team_box(), _read_team_box(), _side_frame()

### Community 36 - "Player season projection"
Cohesion: 0.14
Nodes (8): appearance_rate(), build_player_pools(), draw_appearance_ratio(), load_player_history(), project_season(), remaining_games_per_player(), simulate_player_games(), team_schedule()

### Community 37 - "Player games source"
Cohesion: 0.17
Nodes (8): box_player_traditional table, add_trailing(), attach_impact(), build(), load_player_games(), opponent_strength(), parse_minutes(), _phonedb()

### Community 38 - "Availability features"
Cohesion: 0.16
Nodes (7): add_availability_features(), build_trailing(), load_absences(), per_game_availability(), _phonedb(), player_value(), value_as_of()

### Community 39 - "Value score and OVR concepts"
Cohesion: 0.22
Nodes (12): Chris Paul, 'Empty stats' badge (production OVR vs value OVR >= +8), Player OVR = 65 + 34 x p^2.6 (league percentile), Pricing 5.1: complete assist and free-throw accounting, Roster OVR (minute-weighted top-8), Russell Westbrook, Stephen Curry, Secondary assists (sast x 0.15) and free-throw assists (ftast x 0.17) (+4 more)

### Community 40 - "Ensemble and staleness probes"
Cohesion: 0.16
Nodes (5): fit_one(), main(), scores(), fit_ensemble(), main()

### Community 41 - "Possession simulator concepts"
Cohesion: 0.13
Nodes (7): Next step: pre-game features for unplayed games, League rates measured from 2025-26 play-by-play, Next step: run the trained model inside the simulated world, Season simulator sandbox (possession by possession), League play-by-play rate constants (assisted 2s 54.1%, 3s 85.5%, 20.1% of missed 2s blocked), GameSimulator, PbpWriter

### Community 42 - "2025-26 feature engineering"
Cohesion: 0.18
Nodes (6): Rolling, season and streak features use only earlier games (21,468 team-games match), IMPROVEMENT_REPORT.md (NBA 2025-26 predictor improvement report), Headline metrics on 308 held-out games (accuracy 0.760, AUC 0.832, home-pick baseline 0.610), Rolling form blends home and away games, FeatureEngineer, GameDataLoader

### Community 43 - "Legacy impact score features"
Cohesion: 0.14
Nodes (8): estimate_win_probability(), add_player_tracking_impact(), calculate_defensive_impact(), calculate_matchup_impact(), create_shot_chart(), draw_court(), matplotlib>=3.6, seaborn>=0.12

### Community 44 - "Phone DB cache loader"
Cohesion: 0.27
Nodes (9): _cache_name(), cache_path(), cache_state(), _clear_parts(), load(), _parts_dir(), _pull_key(), _read_manifest() (+1 more)

### Community 45 - "Leak verification scripts"
Cohesion: 0.22
Nodes (5): run(), cmp(), streak_prior(), get_score_margin_for_row(), is_clutch_time()

### Community 46 - "Derived DB impact tables"
Cohesion: 0.25
Nodes (9): game_impact_cache_v4.pkl, player_game_impact (derived table), Independent schema audit (three auditors), game_impact_cache_v5.pkl, build_impact_table(), impact_rows(), _load_sibling(), main() (+1 more)

### Community 47 - "Status and leak findings"
Cohesion: 0.22
Nodes (12): output/engineered_dataset_db.pkl, experiments/2026-10/ one-off analysis scripts, Next step: multi-season betting-line archive, output/market_check.json, Market comparison vs DraftKings closing lines (308 games), Stale 'Model vs Piyasa' sheets in odds_data/*.xlsx, models/backup_observed_roster_2026-10-03/, roster_impact_l10_sum (+4 more)

### Community 48 - "Impact v5 lab"
Cohesion: 0.19
Nodes (5): roster_avail_minutes, differing_columns(), load_frames(), main(), signs_through_prefix()

### Community 49 - "Schema and timing probes"
Cohesion: 0.22
Nodes (6): to_min(), Schema and timing probes (box players, minutes, matchup cache, fit time), _load_sibling(), main(), read_cache(), write_cache_atomic()

### Community 50 - "Simulated possession mechanics"
Cohesion: 0.33
Nodes (12): _clip(), clock_text(), _draw(), emit(), foul(), free_throws(), possession(), rebound() (+4 more)

### Community 51 - "Data stores and lost loader"
Cohesion: 0.35
Nodes (10): box_team_advanced table, box_team_traditional table, Lost CSV-to-MariaDB loader, game_dates table, game_summary table, games table, training_games table (schedule-derived rest), load_master_frame() (+2 more)

### Community 52 - "Impact feature rebuild"
Cohesion: 0.24
Nodes (8): output/engineered_dataset_pregame.pkl, models/feature_list_2025_26.json, check_recipe(), _load_sibling(), main(), rebuild(), rolling_impact(), team_sums()

### Community 53 - "Season impact analysis v1"
Cohesion: 0.19
Nodes (5): identify_scoring_run(), analyze_season_data(), load_and_preprocess_pbp_file(), plot_impact_scores(), process_single_game()

### Community 54 - "2025-26 model analysis"
Cohesion: 0.28
Nodes (7): build_dataset(), chrono_split(), fit_lgbm(), impact_ablation(), main(), model_comparison(), Xy()

### Community 55 - "Dependencies and model comparison"
Cohesion: 0.18
Nodes (11): LightGBM, Logistic / Ridge regression, Model comparison: four model classes within a 1.6-point accuracy band, Random Forest, XGBoost, lightgbm>=4.0, nba_api>=1.2, numpy>=1.23 (+3 more)

### Community 56 - "2025-26 predictor features"
Cohesion: 0.23
Nodes (3): Rest / back-to-back / schedule-density features, Extracted but never rolled features (PACE, OFF/DEF_RATING, TS_PCT, ...), NBAPredictor

### Community 57 - "Information ceiling analysis"
Cohesion: 0.22
Nodes (6): analyse(), brier_decomposition(), collect_predictions(), main(), reliability(), threshold_scan()

### Community 58 - "Phone DB paged fetch"
Cohesion: 0.15
Nodes (7): _adjust_page_size(), fetch_table(), _first_cursor(), _page_query(), _read_parts(), _report_progress(), _run_page()

### Community 59 - "Dashboard metadata API"
Cohesion: 0.18
Nodes (8): api_meta(), api_sim_meta(), _honest_metrics(), _load_registered(), _load_sim_season(), ensureSimMeta(), fillSelect(), loadMeta()

### Community 60 - "Season retrieval (V3 endpoints)"
Cohesion: 0.29
Nodes (8): already_complete(), fmt_gid(), game_dirs(), main(), process_game(), _remap(), _retry(), _team_frame()

### Community 62 - "DB dataset builder"
Cohesion: 0.26
Nodes (6): build(), _load_master(), _load_sibling(), main(), _player_impact_history(), player_records_from_cache()

### Community 63 - "Clutch features"
Cohesion: 0.23
Nodes (5): add_clutch_features(), build_trailing(), clock_to_seconds(), load_clutch_plays(), per_game_clutch()

### Community 64 - "Per-game value computation"
Cohesion: 0.20
Nodes (7): _add_tracked_passing(), clock_seconds(), compute_game_value(), entry(), _credit_passer(), _person_id(), _public()

### Community 65 - "Defensive and tracking backfill"
Cohesion: 0.35
Nodes (8): already_complete(), _exists(), fmt_gid(), game_paths(), main(), process_game(), _retry(), _track_frame()

### Community 66 - "Impact v5 rollout"
Cohesion: 0.25
Nodes (6): Impact engine v5 rollout across the project, output/value_cache_unweighted.pkl, build_v5(), main(), _pricing_version(), team_margin_check()

### Community 67 - "Forward-looking roster impact"
Cohesion: 0.22
Nodes (5): Extend training to the 2019-2024 seasons (about 8289 games), Announced lineup, minutes weighting and injury handling for roster impact, Recency decay via ewm half-life instead of a flat rolling mean, Forward-looking roster impact module (per-player last-10 impact), main()

### Community 68 - "Two-arm retraining"
Cohesion: 0.24
Nodes (5): build_arm_b(), evaluate_arm(), _load_sibling(), main(), segment_ledger()

### Community 69 - "Simulator team sheets"
Cohesion: 0.18
Nodes (4): described_names(), dressed_sheet(), spread_minutes(), TeamSheet

### Community 70 - "Matchup retrieval"
Cohesion: 0.33
Nodes (7): fmt_gid(), main(), matchup_path(), process_game(), _retry(), Player-vs-player matchup impact (BoxScoreMatchupsV3), blocked on data, Defensive matchups table (post-game)

### Community 71 - "Season impact analysis"
Cohesion: 0.22
Nodes (3): validate_game_ids(), analyze_season_data(), plot_impact_scores()

### Community 72 - "README impact score history"
Cohesion: 0.24
Nodes (6): Andre Drummond, Original heuristic impact score, LightGBM outcome models (home win, point differential, total score), Sample game 0022400058, impact_score_calculation/season_impact_engine.py (listed, absent), Simplified impact stub in prediction_engines/2023_2024.py

### Community 73 - "Value pricing rules"
Cohesion: 0.24
Nodes (4): Impact engine pricing 5.1 experiments, free_throw_possessions(), leverage(), price()

### Community 75 - "Play-by-play DB tables"
Cohesion: 0.33
Nodes (5): Defective play-by-play running scores, pbp_defensive_event (derived table), play_by_play table, add_rest_columns(), build_event_table()

### Community 76 - "Simulator player profiles"
Cohesion: 0.28
Nodes (5): build_profiles(), _lines_from_real_box(), PlayerProfile, replacement_profile(), split_name()

### Community 77 - "Legacy impact score critique"
Cohesion: 0.33
Nodes (5): output/analysis_2025_26.json, No opponent or minutes adjustment in impact, Play-by-play impact score (impact_score_agg), Impact segment ledger: close / moderate / blowout games with vs without impact, compute_game_impact()

### Community 78 - "Simulated rankings bridge"
Cohesion: 0.22
Nodes (4): build_ranking_engine(), load_games(), _load_sibling(), power_ranking()

### Community 79 - "Dashboard player rankings view"
Cohesion: 0.36
Nodes (8): api_sim_ranking_players(), Bos istatistik / sessiz deger (empty stats / quiet value) flag, highlightRankTeam(), loadRankPlayers(), ovrBadge(), Uretim (production): legacy impact score, setSimTeam(), setTeam()

### Community 80 - "Matchup retraining ablation"
Cohesion: 0.39
Nodes (5): chrono_split(), fit_fair(), main(), matchup_ablation(), Xy()

### Community 81 - "Season game-id fetcher"
Cohesion: 0.43
Nodes (3): fetch(), main(), season_dir_name()

### Community 82 - "DB connectivity probe"
Cohesion: 0.38
Nodes (4): load_config(), probe(), main(), _print_state()

## Knowledge Gaps
- **17 isolated node(s):** `roster_impact_l10_sum`, `Russell Westbrook`, `Andre Drummond`, `TEAMS`, `FALLBACK_IDS` (+12 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 521 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **8 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `add_rest_columns()` connect `Play-by-play DB tables` to `2025-26 predictor features`, `CSV master loader`, `Leak verification scripts`?**
  _High betweenness centrality (0.020) - this node is a cross-community bridge._
- **What connects `roster_impact_l10_sum`, `Russell Westbrook`, `Andre Drummond` to the rest of the system?**
  _17 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Legacy nba_api retrievers` be split into smaller, more focused modules?**
  _Cohesion score 0.07215541165587419 - nodes in this community are weakly interconnected._
- **Why does `RankingEngine` connect `Power rankings engine` to `Dashboard Flask routes`, `Simulated rankings bridge`?**
  _High betweenness centrality (0.018) - this node is a cross-community bridge._
- **Should `Defensive tracking features` be split into smaller, more focused modules?**
  _Cohesion score 0.06448202959830866 - nodes in this community are weakly interconnected._
- **Why does `defensive_box_score_unavailable_games.txt (8 games without a defensive box score)` connect `Defensive tracking features` to `Box score retrieval (V2)`?**
  _High betweenness centrality (0.015) - this node is a cross-community bridge._
- **Should `Power rankings engine` be split into smaller, more focused modules?**
  _Cohesion score 0.0859465737514518 - nodes in this community are weakly interconnected._