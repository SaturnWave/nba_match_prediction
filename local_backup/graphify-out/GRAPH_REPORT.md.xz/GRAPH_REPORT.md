# Graph Report - .  (2026-08-28)

## Corpus Check
- 48 files · ~77,867 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 421 nodes · 779 edges · 20 communities (19 shown, 1 thin omitted)
- Extraction: 97% EXTRACTED · 3% INFERRED · 0% AMBIGUOUS · INFERRED: 25 edges (avg confidence: 0.89)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Impact Engine Core
- Box Score Scrapers
- Legacy 2023-24 Predictor
- 2025-26 Feature Engineering
- Matchup Impact Module
- Play-by-Play Scraper
- Flask Dashboard API
- Evaluation & Retraining
- 2025-26 Impact Scoring
- Game ID & PBP Retrieval
- 2025-26 Season Retrieval
- Player Tracking Retrieval
- Season Game-ID Fetcher
- Empirical Analysis Suite
- Matchup Box Retrieval
- Duplicate Retrieval Subset
- Shot Charts (prototype)
- Shot Charts (single-game engine)
- Single-Game Tracking Fetch

## God Nodes (most connected - your core abstractions)
1. `is_clutch_time()` - 22 edges
2. `calculate_block_impact()` - 18 edges
3. `calculate_rebound_impact()` - 18 edges
4. `calculate_scoring_impact()` - 18 edges
5. `calculate_steal_impact()` - 17 edges
6. `calculate_turnover_impact()` - 17 edges
7. `calculate_foul_impact()` - 17 edges
8. `NBAPredictor` - 15 edges
9. `ImpactScoreCalculator` - 14 edges
10. `is_last_2_minutes()` - 13 edges

## Surprising Connections (you probably didn't know these)
- `Season / team / month filter controls` --shares_data_with--> `api_games()`  [INFERRED]
  templates/index.html → app.py
- `8 games with no defensive box score (API gap)` --references--> `retrieve_defensive_box_score()`  [EXTRACTED]
  defensive_box_score_unavailable_games.txt → data_retriaval/retrieve_box_scores.py
- `Fair matchup ablation (leak-free early stopping)` --references--> `add_matchup_features()`  [EXTRACTED]
  output/IMPROVEMENT_REPORT.md → prediction_engines/matchup_impact.py
- `Walk-forward / expanding-origin validation` --conceptually_related_to--> `fit_fair()`  [INFERRED]
  output/IMPROVEMENT_REPORT.md → prediction_engines/retrain_with_matchups.py
- `Per-100-possession normalization was dropped` --semantically_similar_to--> `Player Impact Score (event-weighted, per-100-poss)`  [INFERRED] [semantically similar]
  output/IMPROVEMENT_REPORT.md → README.md

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Six per-play impact functions form one engine** — impact_engine_calculate_scoring_impact, impact_engine_calculate_steal_impact, impact_engine_calculate_block_impact, impact_engine_calculate_rebound_impact, impact_engine_calculate_foul_impact, impact_engine_calculate_turnover_impact [EXTRACTED 1.00]
- **Dashboard UI + Flask API surface** — templates_index, app_api_meta, app_api_games, app_api_predict [EXTRACTED 1.00]
- **Data-completeness debt blocking a clean retrain** — output_improvement_report_missing_boxes_2024_25, output_improvement_report_defensive_unused, defensive_box_score_unavailable_games, output_improvement_report_unused_extracted_stats [INFERRED 0.85]

## Communities (20 total, 1 thin omitted)

### Community 0 - "Impact Engine Core"
Cohesion: 0.07
Nodes (80): calculate_enhanced_impact_score(), load_and_preprocess_data(), plot_cumulative_impact(), plot_impact_scores(), Plots a bar chart of player impact scores., Plots cumulative impact score over the game with enhanced metrics., Creates a detailed breakdown of a player's impact by play type., Loads and preprocesses only the play-by-play CSV file. (+72 more)

### Community 1 - "Box Score Scrapers"
Cohesion: 0.07
Nodes (50): format_season(), Shared helpers for the NBA data-retrieval scripts. ``format_season`` and…, Convert season format from "YYYY-YY" to "YYYY_YYYY" for directory structure, Read game IDs from the corresponding CSV file Args: season (str): Season in…, read_game_ids(), check_if_box_score_data_exists(), format_game_id(), get_retry_delay() (+42 more)

### Community 2 - "Legacy 2023-24 Predictor"
Cohesion: 0.08
Nodes (12): away_score feature importance (legacy), home_score feature importance (legacy), home_win feature importance (legacy), point_diff feature importance (legacy), total_score feature importance (legacy), Training log 2025-05-12 (2022-23 + 2023-24 run), FeatureEngineer, GameDataLoader (+4 more)

### Community 3 - "2025-26 Feature Engineering"
Cohesion: 0.08
Nodes (18): away_score feature importance 2025-26, home_score feature importance 2025-26, home_win feature importance 2025-26, point_diff feature importance 2025-26, total_score feature importance 2025-26, shift(1) leakage discipline holds the whole model up, 146 box-score-less 2024-25 games train with zeros, Rest / back-to-back schedule features (missing) (+10 more)

### Community 4 - "Matchup Impact Module"
Cohesion: 0.09
Nodes (30): add_matchup_features(), _add_trailing(), build_defender_game_table(), build_offense_game_table(), _detect_seasons(), _full_name(), get_current_matchup_impact(), _get_default_instance() (+22 more)

### Community 5 - "Play-by-Play Scraper"
Cohesion: 0.14
Nodes (24): calculate_progress_percentage(), check_if_pbp_data_exists(), check_if_tracking_data_exists(), create_season_dir(), format_game_id(), get_season_formatted(), process_all_seasons(), process_season_games() (+16 more)

### Community 6 - "Flask Dashboard API"
Cohesion: 0.15
Nodes (23): api_games(), api_meta(), api_predict(), _badge(), _build_player_games(), _game_summary(), get_state(), index() (+15 more)

### Community 7 - "Evaluation & Retraining"
Cohesion: 0.13
Nodes (18): Model accuracy comparison, Model AUC comparison, Model MAE comparison, Model RMSE comparison, Improvement Report (2025-26 predictor), Probability calibration (isotonic/Platt, Brier), Elo/Glicko team-strength baseline (missing), Late-season split overstates full-season skill (+10 more)

### Community 8 - "2025-26 Impact Scoring"
Cohesion: 0.29
Nodes (16): _block_impact(), clock_to_seconds(), compute_game_impact(), expected_points(), _foul_impact(), is_clutch(), is_last_2min(), margin() (+8 more)

### Community 9 - "Game ID & PBP Retrieval"
Cohesion: 0.16
Nodes (14): check_if_data_exists(), get_regular_season_game_ids(), get_season_formatted_filename(), process_all_games(), Retrieves all game IDs from the specified NBA regular season. Args: season…, Saves play-by-play data to CSV with the specified directory structure.…, Check if play-by-play data already exists for the given game ID. Args: game_id…, Process all games from the CSV file of game IDs. Only process games that don't… (+6 more)

### Community 10 - "2025-26 Season Retrieval"
Cohesion: 0.23
Nodes (13): already_complete(), fmt_gid(), game_dirs(), main(), process_game(), Focused, resumable retrieval of the 2025-26 NBA season game data needed by the…, Rename V3 columns to V2 schema; add PLAYER_NAME for player frames., Pick the 2-row team-totals frame (no personId). (+5 more)

### Community 11 - "Player Tracking Retrieval"
Cohesion: 0.24
Nodes (10): check_if_tracking_data_exists(), process_all_games_tracking_data(), Retrieves player tracking data for a given game ID using the NBA API. Args:…, Check if player tracking data already exists for the given game ID. Args:…, Process all games from the CSV file of game IDs to retrieve player tracking…, Validates game IDs from the CSV file to ensure they are in the correct format…, Saves player tracking data to CSV with the specified directory structure.…, retrieve_player_tracking_data() (+2 more)

### Community 12 - "Season Game-ID Fetcher"
Cohesion: 0.22
Nodes (8): Saves the DataFrame to a CSV file. Args: df (pd.DataFrame): DataFrame to save…, Retrieves all game IDs for a specific NBA season. Args: season (str): Season in…, Retrieves play-by-play data for a given game ID using the NBA API. Args:…, Saves the game IDs for a season to a CSV file. Args: games_df (pd.DataFrame):…, retrieve_play_by_play(), retrieve_season_games(), save_game_ids_to_csv(), save_to_csv()

### Community 13 - "Empirical Analysis Suite"
Cohesion: 0.44
Nodes (8): build_dataset(), chrono_split(), fit_lgbm(), impact_ablation(), main(), model_comparison(), Empirical analysis backing the improvement report for the 2025-26 predictor.…, Xy()

### Community 14 - "Matchup Box Retrieval"
Cohesion: 0.52
Nodes (6): fmt_gid(), main(), matchup_path(), process_game(), Resumable retrieval of BoxScoreMatchupsV3 (defender-vs-offensive-player…, _retry()

### Community 15 - "Duplicate Retrieval Subset"
Cohesion: 0.40
Nodes (4): Saves the DataFrame to a CSV file. Args: df (pd.DataFrame): DataFrame to save…, Retrieves play-by-play data for a given game ID using the NBA API. Args:…, retrieve_play_by_play(), save_to_csv()

### Community 16 - "Shot Charts (prototype)"
Cohesion: 0.50
Nodes (4): create_shot_chart(), draw_court(), Creates a shot chart for a specific team., Draws a basketball court.

### Community 17 - "Shot Charts (single-game engine)"
Cohesion: 0.50
Nodes (4): create_shot_chart(), draw_court(), Creates a shot chart for a specific team., Draws a basketball court.

## Knowledge Gaps
- **21 isolated node(s):** `Elo/Glicko team-strength baseline (missing)`, `146 box-score-less 2024-25 games train with zeros`, `Rest / back-to-back schedule features (missing)`, `PACE / OFF_RATING / DEF_RATING extracted but never rolled`, `Season / team / month filter controls` (+16 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **1 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Player Impact Score (event-weighted, per-100-poss)` connect `Impact Engine Core` to `Box Score Scrapers`, `2025-26 Feature Engineering`?**
  _High betweenness centrality (0.310) - this node is a cross-community bridge._
- **Why does `Scrape -> impact score -> LightGBM pipeline` connect `Box Score Scrapers` to `Legacy 2023-24 Predictor`?**
  _High betweenness centrality (0.217) - this node is a cross-community bridge._
- **Why does `shift(1) leakage discipline holds the whole model up` connect `2025-26 Feature Engineering` to `Impact Engine Core`?**
  _High betweenness centrality (0.204) - this node is a cross-community bridge._
- **What connects `Elo/Glicko team-strength baseline (missing)`, `146 box-score-less 2024-25 games train with zeros`, `Rest / back-to-back schedule features (missing)` to the rest of the system?**
  _21 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Impact Engine Core` be split into smaller, more focused modules?**
  _Cohesion score 0.06703146374829001 - nodes in this community are weakly interconnected._
- **Should `Box Score Scrapers` be split into smaller, more focused modules?**
  _Cohesion score 0.07256894049346879 - nodes in this community are weakly interconnected._
- **Should `Legacy 2023-24 Predictor` be split into smaller, more focused modules?**
  _Cohesion score 0.07682926829268293 - nodes in this community are weakly interconnected._